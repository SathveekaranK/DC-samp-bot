# Boss-Discord-System
This is a samp-discord connector filterscript which generally connects your samp server with discord. Everything is setuped in this filterscript you just have to put your channels ids.

Features Version - 0.1

1 - In-game chat feature.
2 - Discord commands like - /players , /serverinfo , /ip , /commands.
3 - Command log system (for this you have to shift the code to your main script).
4 - Server start message.
5 - Player connect/disconnect messages.
6 - Fixed discord-command include.

